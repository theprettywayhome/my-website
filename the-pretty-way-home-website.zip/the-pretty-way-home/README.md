# The Pretty Way Home — website starter

A responsive, multi-page static website ready for GitHub Pages.

## Files
- `index.html` — home
- `about.html` — about the brand
- `services.html` — travel journal, group adventures and merchandise
- `gallery.html` — photo gallery (currently uses temporary remote sample photos)
- `contact.html` — contact form that opens the visitor's email app
- `assets/style.css` and `assets/script.js` — design and small interactions

## Before publishing
1. Replace `hello@yourdomain.com` in `contact.html` and `assets/script.js` with your real contact email.
2. Replace the sample gallery and banner photos with your own photographs (or licensed images).
3. Edit the About and Services wording so it accurately describes your business.
4. Add your social media links and business contact details.
5. If you want customers to pay for merchandise or book/pay for tours online, connect a dedicated shop/booking provider. This starter site does not process payments or store bookings.

## Publish with GitHub Pages
1. Create a **public** GitHub repository, e.g. `the-pretty-way-home`.
2. Upload the contents of this folder (the HTML files, `assets` folder and this README) to the repository root. Do not upload the ZIP itself as the website.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then Save.
6. Wait a few minutes. GitHub will show your published `github.io` address in the Pages settings.

## Connect your domain
1. In **Settings → Pages → Custom domain**, enter your domain (for example `www.example.com`) and Save.
2. At your domain registrar, add the DNS records recommended by GitHub. For a `www` hostname, this is usually a CNAME pointing to `YOUR-GITHUB-USERNAME.github.io` (no repository name or `https://`).
3. For an apex/root domain (example.com), use the four GitHub Pages A records listed in GitHub's current documentation. If you want both root and `www`, configure the recommended records for both.
4. Allow time for DNS to update, then enable **Enforce HTTPS** in GitHub Pages.

Official guide: https://docs.github.com/en/pages

## Important notes
- GitHub Pages hosts static websites. The contact form opens the visitor's email app; it does not send or store messages on its own.
- Never put passwords, API keys, private customer data or other secrets in this public repository.
- Check that your domain registrar supports the DNS records you need.
